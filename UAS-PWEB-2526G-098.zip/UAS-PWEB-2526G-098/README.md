# UAS Pemrograman Web - Berbasis Project

## Identitas Mahasiswa
* **Nama:** [Sulis Inaya Masruro]
* **NIM:** [240631100098]
* **Judul Aplikasi:** Aplikasi To-Do List (Sistem Catatan Tugas Sederhana)

## Deskripsi Singkat
Aplikasi To-Do List ini adalah sebuah sistem manajemen tugas sederhana berbasis web yang dibangun menggunakan HTML5, CSS eksternal, PHP Native, dan database MySQL. Aplikasi ini mengimplementasikan fungsi CRUD (Create, Read, Update, Delete) secara penuh untuk membantu pengguna dalam mencatat, memantau proses, dan mengelola tugas harian mereka.

## Struktur Database
Aplikasi ini menggunakan database `db_todolist` dengan satu tabel bernama `tugas` yang memiliki struktur sebagai berikut:
* `id` (INT, Primary Key, Auto Increment) - ID Unik Tugas
* `judul_tugas` (VARCHAR) - Nama atau Judul Tugas
* `deskripsi` (TEXT) - Penjelasan Detail Tugas
* `status` (VARCHAR) - Status Tugas (Belum Selesai / Proses / Selesai)

## Screenshot Aplikasi
*(Silakan ambil screenshot tampilan index.php kamu, lalu simpan fotonya di folder img/ dengan nama `tampilan.png`)*
![Tampilan Utama](img/tampilan.png)

## Cara Menjalankan Aplikasi
1. Pastikan aplikasi **XAMPP** sudah terinstal di komputer Anda.
2. Pindahkan folder `UAS-PWEB-NIM` ke dalam direktori `C:/xampp/htdocs/`.
3. Buka **XAMPP Control Panel** lalu jalankan service **Apache** dan **MySQL**.
4. Buka browser dan pergi ke halaman `localhost/phpmyadmin`.
5. Buat database baru bernama `db_todolist`.
6. Import file `database.sql` yang tersedia di dalam folder project ini ke database tersebut.
7. Buka browser baru lalu ketik URL: `http://localhost/UAS-PWEB-NIM/index.php`.
8. Aplikasi siap digunakan.

## Pernyataan Penggunaan GenAI
Proyek ini dikembangkan dengan bantuan Perangkat Kecerdasan Artifisial (GenAI) sebagai asisten belajar interaktif langkah-demi-langkah guna memahami alur implementasi CRUD PHP Native dan MySQL.